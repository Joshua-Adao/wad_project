from django.conf.urls import include, url
from django.contrib import admin
from django.conf.urls.static import static, settings

urlpatterns = [

    url(r'^admin/', include(admin.site.urls)),
               
    url(r'', include('landpage.urls')),
    url(r'', include('registration.urls')),
    url(r'', include('login.urls')),
    url(r'', include('account.urls')),
    url(r'', include('registrar.urls')),
    url(r'', include('student.urls')),
    url(r'', include('teacher.urls')),
    url(r'', include('publisher.urls')),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
